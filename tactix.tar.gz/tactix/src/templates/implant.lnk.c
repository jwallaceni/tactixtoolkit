#include <windows.h>
#include <shobjidl.h>  // For IShellLink
#include <shlguid.h>   // For CLSID_ShellLink
#include <objbase.h>   // For CoInitialize

int main() {
    HRESULT hres;
    IShellLink* psl;
    IPersistFile* ppf;
    WCHAR wsz[MAX_PATH];

    // Initialize COM library
    hres = CoInitialize(NULL);
    if (FAILED(hres)) {
        return 1;
    }

    // Create ShellLink object
    hres = CoCreateInstance(&CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, &IID_IShellLink, (void**)&psl);
    if (SUCCEEDED(hres)) {
        // Set the path to the target executable
        psl->lpVtbl->SetPath(psl, L"C:\\Path\\To\\Target.exe");

        // Optionally set working directory
        psl->lpVtbl->SetWorkingDirectory(psl, L"C:\\Path\\To");

        // Optionally set description
        psl->lpVtbl->SetDescription(psl, L"My Shortcut");

        // Query IPersistFile interface for saving the shortcut
        hres = psl->lpVtbl->QueryInterface(psl, &IID_IPersistFile, (void**)&ppf);
        if (SUCCEEDED(hres)) {
            // Convert shortcut file path to wide string
            MultiByteToWideChar(CP_ACP, 0, "C:\\Path\\To\\Shortcut.lnk", -1, wsz, MAX_PATH);

            // Save the shortcut
            hres = ppf->lpVtbl->Save(ppf, wsz, TRUE);
            ppf->lpVtbl->Release(ppf);
        }
        psl->lpVtbl->Release(psl);
    }

    CoUninitialize();
    return 0;
}
