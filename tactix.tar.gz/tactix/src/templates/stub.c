#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

void rol_decrypt(uint8_t* data, size_t len, uint8_t bits) {
    for (size_t i = 0; i < len; i++) {
        data[i] = (data[i] >> bits) | (data[i] << (8 - bits));
    }
}

void sub_decrypt(uint8_t* data, size_t len, uint8_t key) {
    for (size_t i = 0; i < len; i++) {
        data[i] = (uint8_t)(data[i] - key);
    }
}

void xor_decrypt(uint8_t* data, size_t len, uint8_t key) {
    for (size_t i = 0; i < len; i++) {
        data[i] ^= key;
    }
}

int main() {
    // Encrypted shellcode from your example
    uint8_t encrypted_shellcode[] = { /* put your encrypted bytes here */ };
    size_t len = sizeof(encrypted_shellcode);

    printf("Encrypted shellcode:\n");
    for (size_t i = 0; i < len; i++) {
        printf("\\x%02x", encrypted_shellcode[i]);
    }
    printf("\n");

    // Decrypt in reverse order
    rol_decrypt(encrypted_shellcode, len, 3);
    sub_decrypt(encrypted_shellcode, len, 0x10);
    xor_decrypt(encrypted_shellcode, len, 0xAA);

    printf("Decrypted shellcode:\n");
    for (size_t i = 0; i < len; i++) {
        printf("\\x%02x", encrypted_shellcode[i]);
    }
    printf("\n");

    return 0;
}
