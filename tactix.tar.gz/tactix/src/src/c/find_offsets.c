#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

void find_bytes(const uint8_t *data, size_t data_len, const uint8_t *pattern, size_t pattern_len) {
    int found = 0;
    for (size_t i = 0; i <= data_len - pattern_len; i++) {
        if (memcmp(data + i, pattern, pattern_len) == 0) {
            printf("Found pattern at offset: %zu\n", i);
            found = 1;
        }
    }
    if (!found) {
        printf("Pattern not found\n");
    }
}

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Usage: %s shellcode.bin ip port\n", argv[0]);
        printf("Example IP: 0x0100007f (127.0.0.1)\n");
        printf("Example port: 0x115c (4444)\n");
        return 1;
    }

    const char *filename = argv[1];
    uint32_t ip = (uint32_t)strtoul(argv[2], NULL, 0);
    uint16_t port = (uint16_t)strtoul(argv[3], NULL, 0);

    FILE *f = fopen(filename, "rb");
    if (!f) {
        perror("Failed to open shellcode file");
        return 1;
    }

    fseek(f, 0, SEEK_END);
    size_t filesize = ftell(f);
    rewind(f);

    uint8_t *buffer = malloc(filesize);
    if (!buffer) {
        perror("Memory allocation failed");
        fclose(f);
        return 1;
    }

    fread(buffer, 1, filesize, f);
    fclose(f);

    // Prepare little-endian byte patterns
    uint8_t ip_bytes[4];
    ip_bytes[0] = (ip >> 0) & 0xFF;
    ip_bytes[1] = (ip >> 8) & 0xFF;
    ip_bytes[2] = (ip >> 16) & 0xFF;
    ip_bytes[3] = (ip >> 24) & 0xFF;

    uint8_t port_bytes[2];
    port_bytes[0] = (port >> 0) & 0xFF;
    port_bytes[1] = (port >> 8) & 0xFF;

    printf("Searching for IP bytes: %02x %02x %02x %02x\n", ip_bytes[0], ip_bytes[1], ip_bytes[2], ip_bytes[3]);
    find_bytes(buffer, filesize, ip_bytes, 4);

    printf("Searching for port bytes: %02x %02x\n", port_bytes[0], port_bytes[1]);
    find_bytes(buffer, filesize, port_bytes, 2);

    free(buffer);
    return 0;
}
