#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

void xor_encrypt(uint8_t* data, size_t len, uint8_t key) {
    for (size_t i = 0; i < len; i++) {
        data[i] ^= key;
    }
}

void add_encrypt(uint8_t* data, size_t len, uint8_t key) {
    for (size_t i = 0; i < len; i++) {
        data[i] = (uint8_t)(data[i] + key);
    }
}

void rol_encrypt(uint8_t* data, size_t len, uint8_t bits) {
    for (size_t i = 0; i < len; i++) {
        data[i] = (data[i] << bits) | (data[i] >> (8 - bits));
    }
}

int main() {
    // Example shellcode (NOP sled for demo)
    uint8_t shellcode[] = { 0x4c, 0x01, 0x03, 0x00, 0x21, 0x37 };
    size_t len = sizeof(shellcode);

    printf("\n");
    printf("Original shellcode:\n");
    printf("\n");
    for (size_t i = 0; i < len; i++) {
        printf("\\x%02x", shellcode[i]);
    }
    printf("\n");
    
    printf("\n");

    // Apply multiple encryptions
    xor_encrypt(shellcode, len, 0xAA);
    add_encrypt(shellcode, len, 0x10);
    rol_encrypt(shellcode, len, 3);

    printf("Encrypted shellcode:\n");
    printf("\n");
    for (size_t i = 0; i < len; i++) {
        printf("\\x%02x", shellcode[i]);
    }
    printf("\n");

    return 0;
}
