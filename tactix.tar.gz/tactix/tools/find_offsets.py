import sys

def find_bytes(data, pattern):
    offsets = []
    plen = len(pattern)
    for i in range(len(data) - plen + 1):
        if data[i:i+plen] == pattern:
            offsets.append(i)
    return offsets

def main():
    if len(sys.argv) != 4:
        print("Usage: python3 find_offsets.py shellcode.bin ip port")
        print("Example IP: 127.0.0.1 as 0x0100007f")
        print("Example port: 4444 as 0x115c")
        return

    shellcode_file = sys.argv[1]
    ip = int(sys.argv[2], 0)
    port = int(sys.argv[3], 0)

    with open(shellcode_file, "rb") as f:
        data = f.read()

    # IP in little-endian bytes
    ip_bytes = ip.to_bytes(4, byteorder='little')
    # Port in little-endian bytes (2 bytes)
    port_bytes = port.to_bytes(2, byteorder='little')

    ip_offsets = find_bytes(data, ip_bytes)
    port_offsets = find_bytes(data, port_bytes)

    if ip_offsets:
        print(f"Found IP bytes {ip_bytes.hex()} at offsets: {ip_offsets}")
    else:
        print(f"IP bytes {ip_bytes.hex()} not found")

    if port_offsets:
        print(f"Found port bytes {port_bytes.hex()} at offsets: {port_offsets}")
    else:
        print(f"Port bytes {port_bytes.hex()} not found")

if __name__ == "__main__":
    main()
